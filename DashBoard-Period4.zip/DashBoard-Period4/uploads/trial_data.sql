insert into user_info(user_id, user_name, department_class, face_encodings)
values("TE123", "IT_TEACHER", "234abd"),
("TE234", "LG_TEACHER", "235abd");


